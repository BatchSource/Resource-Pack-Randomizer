===============
USAGE:

Unzip and run start.bat
Everything must be in the same folder!
===============